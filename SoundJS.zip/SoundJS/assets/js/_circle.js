/*****************
*** CIRCLE INIT **
******************/
class Circle {
    constructor() {
        
    }
    draw() {

    }
    frame() {

    }
}
